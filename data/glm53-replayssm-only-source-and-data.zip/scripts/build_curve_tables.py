"""Build table inputs only after both hardware runs are complete."""
import csv,gzip,json,pathlib,statistics
P=pathlib.Path(__file__).resolve().parent;OUT=P.parents[1]/'outputs'
data={h:json.load(gzip.open(P/(h+'-compute-curves.json.gz'),'rt',encoding='utf-8')) for h in ['850','850e']}
for h,d in data.items():
    assert d['measured_batches']==100,(h,d['measured_batches'])
    assert [r['batch_per_dp'] for r in d['rows']]==list(range(1,101))
names=set().union(*(r['operators'] for r in data['850']['rows']))
ranking=sorted(names,key=lambda n:statistics.mean(r['operators'].get(n,{}).get('us_per_rank_forward',0) for r in data['850']['rows']),reverse=True)[:10]
assert len(ranking)==10
file=OUT/'glm53-replayssm-only-top10.csv'
with file.open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=['rank_by_850_all_batch_mean','operator','batch_per_DP_rank','num_tokens_per_DP','850_us_per_rank_forward','850E_us_per_rank_forward'])
    writer.writeheader()
    for rank,op in enumerate(ranking,1):
        for b in range(1,101):
            row={'rank_by_850_all_batch_mean':rank,'operator':op,'batch_per_DP_rank':b,'num_tokens_per_DP':6*b}
            for h,label in [('850','850'),('850e','850E')]:
                # Zero means this operator type was absent in that measured graph.
                row[label+'_us_per_rank_forward']=data[h]['rows'][b-1]['operators'].get(op,{}).get('us_per_rank_forward',0)
            writer.writerow(row)
assert file.stat().st_size<1_000_000
(P/'top10-selection.json').write_text(json.dumps(ranking,indent=2))
print(json.dumps({'file':str(file),'top10':ranking}))
