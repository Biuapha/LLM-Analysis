"""Render the 2x5+1 figure; validate data and text geometry without image reads."""
from pathlib import Path
from collections import defaultdict
import csv
import hashlib
import io
import json
import math
import os
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs'
os.environ['MPLCONFIGDIR'] = str(ROOT / 'work/matplotlib-config')
sys.path.insert(0, 'C:/Users/g00672350/Documents/Codex/2026-11-03/https-biuapha-github-io-llm-analysis-2/work/plot-deps')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import StrMethodFormatter

font_manager.fontManager.addfont('C:/Windows/Fonts/msyh.ttc')
font_manager.fontManager.addfont('C:/Windows/Fonts/msyhbd.ttc')
plt.rcParams.update({'font.family': 'Microsoft YaHei', 'axes.unicode_minus': False, 'svg.fonttype': 'path'})
STEM = 'glm53-replayssm-only-'
sources = [OUT / (STEM + n) for n in ['top10.csv', 'full-itl-ep8-ep16-ep32.csv', 'full-itl-method.json', 'full-itl-ep8-ep16-ep32-method.json']]
with sources[0].open(encoding='utf-8-sig', newline='') as f:
    op_rows = list(csv.DictReader(f))
with sources[1].open(encoding='utf-8-sig', newline='') as f:
    itl_rows = list(csv.DictReader(f))
baseline_method = json.loads(sources[2].read_text())
method = json.loads(sources[3].read_text(encoding='utf-8'))
assert method['EP8_baseline_unchanged'] and not method['step_normalization_applied']
hardware = ['850', '850E']
batches = list(range(1, 101))
ordered, operators, itls = {}, defaultdict(lambda: defaultdict(dict)), defaultdict(dict)
for row in op_rows:
    op, b, rank = row['operator'], int(row['batch_per_DP_rank']), int(row['rank_by_850_all_batch_mean'])
    assert ordered.setdefault(rank, op) == op
    for hw in hardware:
        assert b not in operators[op][hw]
        operators[op][hw][b] = float(row[hw + '_us_per_rank_forward'])
for row in itl_rows:
    hw, b = row['hardware'], int(row['batch_per_DP'])
    for ep, col in [(8, 'EP8_full_ITL_ms_per_cycle'), (16, 'EP16_full_ITL_ms_per_cycle_GMM_halved'), (32, 'EP32_full_ITL_ms_per_cycle_GMM_quartered')]:
        assert b not in itls[hw, ep]
        itls[hw, ep][b] = float(row[col])
assert len(ordered) == 10 and len(itls) == 6
for series in [operators[ordered[i]][hw] for i in range(1, 11) for hw in hardware] + list(itls.values()):
    assert sorted(series) == batches and all(math.isfinite(v) and v >= 0 for v in series.values())

colors = {'850': '#2563B3', '850E': '#D87522'}
styles = {8: '-', 16: (0, (5, 2.2)), 32: (0, (1.3, 2))}
fig = plt.figure(figsize=(14, 27), dpi=140, facecolor='white')
fig.text(.085, .982, 'MTP5 · ReplaySSM only · QKV TP disabled', fontsize=21, fontweight='bold', color='#172B4D', va='top')
fig.text(.085, .962, 'GLM-5.3-Flash · 850 vs 850E · Batch 1–100 · EP8 基线与 EP16 / EP32 估算', fontsize=12, color='#526277', va='top')
fig.text(.085, .944, '上方：当前 DP8 / TP1 / EP8 减层主模型的 Top 10 非通信算子；剔除 dispatch / combine、HCCL / hcom、Slice。', fontsize=9.8, color='#64748B', va='top')
fig.text(.085, .929, '每个 DP 均有 B 条序列，主模型 num_tokens = 6B；每次主 forward 内同类 kernel 求和，再平均 8 卡 × 20 周期。', fontsize=9.8, color='#64748B', va='top')
grid = fig.add_gridspec(5, 2, left=.085, right=.97, top=.884, bottom=.342, hspace=.52, wspace=.25)
axes, checks, top_handles = [], [], []

def style_axis(ax):
    ax.set_facecolor('white')
    ax.set_xlim(0, 102)
    ax.set_xticks([1, 20, 40, 60, 80, 100])
    ax.set_xlabel('Batch（每个 DP rank）', fontsize=10, labelpad=7, color='#475569')
    ax.tick_params(axis='both', labelsize=9.2, colors='#526277', length=0, pad=5)
    ax.grid(axis='y', color='#E2E8F0', linewidth=.75, zorder=0)
    ax.grid(axis='x', color='#F0F3F7', linewidth=.6, zorder=0)
    for name, spine in ax.spines.items():
        spine.set_visible(name in ['bottom', 'left'])
        spine.set_color('#CBD5E1')

def line(ax, values, hw, ep, **kw):
    expected = [values[b] for b in batches]
    obj, = ax.plot(batches, expected, color=colors[hw], linestyle=styles[ep], **kw)
    assert list(obj.get_xdata()) == batches and list(obj.get_ydata()) == expected
    checks.append({'hardware': hw, 'ep': ep, 'points': 100, 'matches_CSV': True})
    return obj

for i in range(10):
    op = ordered[i + 1]
    ax = fig.add_subplot(grid[i // 2, i % 2]); axes.append(ax)
    for hw in hardware:
        obj = line(ax, operators[op][hw], hw, 8, linewidth=2,
                   marker='o' if hw == '850' else '^', markersize=3,
                   markevery=[0, 19, 39, 59, 79, 99], markerfacecolor='white',
                   markeredgewidth=1, label=hw + ' / EP8')
        if hw == '850E':
            obj.set_linestyle((0, (4, 2)))
        if i == 0:
            top_handles.append(obj)
    style_axis(ax)
    ax.set_title(f'{i + 1:02d}  {op}', loc='left', fontsize=11.6, fontweight='bold', color='#243B53', pad=11)
    ax.set_ylabel('耗时（μs / 卡 / 次）', fontsize=10, labelpad=8, color='#475569')
    ymax = max(max(operators[op][h].values()) for h in hardware)
    target = ymax / 4
    power = 10 ** math.floor(math.log10(target))
    step = next(s for s in [1, 2, 2.5, 5, 10] if s >= target / power) * power
    top = math.ceil(ymax * 1.07 / step) * step
    ax.set_ylim(0, top)
    ax.set_yticks([step * n for n in range(round(top / step) + 1)])
    ax.yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
top_legend = fig.legend(top_handles, [h + ' / EP8' for h in hardware], loc='center', bbox_to_anchor=(.52, .909), ncol=2, frameon=False, fontsize=11.5, handlelength=3, columnspacing=3)

fig.text(.085, .304, '11  满层总 ITL · EP8 / EP16 / EP32', fontsize=17, fontweight='bold', color='#172B4D', va='top')
fig.text(.085, .286, '45 层主模型 + MTP5；EP8 使用当前满层测量校准。EP16 / EP32 为两类 GMM 缩至 1/2、1/4 的条件估算。', fontsize=10.0, color='#526277', va='top')
itl_ax = fig.add_axes([.085, .100, .885, .145]); axes.append(itl_ax)
handles, labels = [], []
for ep in [8, 16, 32]:
    for hw in hardware:
        obj = line(itl_ax, itls[hw, ep], hw, ep, linewidth=2.15, zorder=3)
        handles.append(obj)
        labels.append(f'{hw} · EP{ep}' + ('（基线）' if ep == 8 else '（估算）'))
for hw in hardware:
    points = sorted(map(int, baseline_method['hardware'][hw.lower()]['anchors_ms']))
    itl_ax.scatter(points, [itls[hw, 8][b] for b in points], marker='*', s=100, color=colors[hw], edgecolors='white', zorder=5)
style_axis(itl_ax)
itl_ax.set_xticks([1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
itl_ax.set_ylim(bottom=0)
itl_ax.set_ylabel('总 ITL（ms / 轮；不折算步长）', fontsize=10.5, labelpad=10, color='#475569')
itl_legend = fig.legend(handles, labels, loc='center', bbox_to_anchor=(.52, .264), ncol=3, frameon=False, fontsize=10, handlelength=3.5, columnspacing=2.5, labelspacing=.65)
fig.text(.085, .059, 'EP 扩展：G = 两类满层 GMM 估算合计；EP16 = EP8 − 0.5G，EP32 = EP8 − 0.75G。其他算子、通信和等待保持不变。', fontsize=9.3, color='#64748B', va='top')
fig.text(.085, .044, '每类 GMM = 31×KDA-MoE + 11×SFA-MoE + 5 次 draft；暂用当前 EP8 总 ITL 系数校准 GMM，未作独立满层 GMM 校准。', fontsize=9.0, color='#64748B', va='top')
fig.text(.085, .029, 'EP16 / EP32 未做多机实测；跨机通信、负载均衡与重叠变化未建模。星号仅标出 EP8 满层实测校准点。', fontsize=9.2, color='#64748B', va='top')
anchor_ranges = '；'.join(f"{h} B{min(map(int, baseline_method['hardware'][h.lower()]['anchors_ms']))}–{max(map(int, baseline_method['hardware'][h.lower()]['anchors_ms']))}" for h in hardware)
fig.text(.085, .014, '输入128K；算子输出1K，满层8K。EP8实测校准范围：' + anchor_ranges + '；范围外为外推。', fontsize=9.1, color='#64748B', va='top')

fig.canvas.draw()
renderer = fig.canvas.get_renderer()
legends = [top_legend, itl_legend]
texts = list(fig.texts) + [t for legend in legends for t in legend.get_texts()]
for ax in axes:
    texts.extend([ax.xaxis.label, ax.yaxis.label, ax.title, ax._left_title])
    texts.extend(ax.get_xticklabels() + ax.get_yticklabels())
for obj in texts:
    if obj.get_text():
        box = obj.get_window_extent(renderer)
        assert box.x0 >= -1 and box.y0 >= -1 and box.x1 <= fig.bbox.width + 1 and box.y1 <= fig.bbox.height + 1, (obj.get_text(), str(box))
axis_boxes = [ax.get_tightbbox(renderer) for ax in axes]
caption_boxes = [t.get_window_extent(renderer) for t in fig.texts] + [l.get_window_extent(renderer) for l in legends]
for i, box in enumerate(axis_boxes):
    for other in axis_boxes[i + 1:]:
        assert not box.overlaps(other), 'Subplots overlap'
for i, box in enumerate(caption_boxes):
    for other in caption_boxes[i + 1:] + axis_boxes:
        assert not box.overlaps(other), 'Caption or legend overlaps'
assert len(axes) == 11 and sum(len(ax.lines) for ax in axes) == 26

name = STEM + 'top10-and-full-itl-ep8-ep16-ep32'
png, svg = OUT / (name + '.png'), OUT / (name + '.svg')
for dpi in [150, 140, 130, 120]:
    fig.savefig(png, dpi=dpi, facecolor='white')
    if png.stat().st_size < 950_000:
        break
buffer = io.StringIO()
fig.savefig(buffer, format='svg', facecolor='white')
svg.write_text('\n'.join(s.rstrip() for s in buffer.getvalue().splitlines()) + '\n', encoding='utf-8')
plt.close(fig)
assert 0 < png.stat().st_size < 1_000_000 and 0 < svg.stat().st_size < 1_000_000
report = {'layout': '2 columns x 5 operator rows + 1 full-width ITL panel',
          'panels': 11, 'operator_curves': 20, 'ITL_curves': 6, 'total_curves': 26,
          'points_per_curve': 100, 'all_lines_match_CSV': True,
          'operator_panels_newly_measured': True, 'EP8_ITL_newly_calibrated': True,
          'geometry_checked': True, 'image_files_read': 0, 'new_EP8_NPU_measurements': True,
          'EP16_EP32_measured': False, 'step_normalization_applied': False,
          'png_dpi': dpi, 'sources': [{'name': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
          'files': [{'name': p.name, 'bytes': p.stat().st_size} for p in [png, svg]]}
(OUT / (name + '-validation.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
