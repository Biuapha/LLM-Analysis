"""Calibrate a layer-span model to new, unprofiled full-depth client windows.

Input selection is explicit. Old 100/61 ms anchors are never read. No fixed
accepted-token length or MTP step multiplier is applied to measured time.
"""
import bisect,csv,gzip,json,math,pathlib,statistics,sys
P=pathlib.Path(__file__).resolve().parent;OUT=P.parents[1]/'outputs'
config=json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))
assert config['replayssm'] is True and config['qkv_iproj_tp']==1
records=[];details={}
def read(file):
    path=P/file
    with gzip.open(path,'rt',encoding='utf-8') as f:return json.load(f)

def topology_entries(value):
    if isinstance(value,dict):
        return [value] if 'ep' in value else [r for v in value.values() for r in topology_entries(v)]
    return [r for v in value for r in topology_entries(v)] if isinstance(value,list) else []
def interpolate(x,xs,ys):
    if x<=xs[0]:return ys[0]
    if x>=xs[-1]:return ys[-1]
    i=bisect.bisect_right(xs,x);left,right=xs[i-1],xs[i]
    return ys[i-1]+(ys[i]-ys[i-1])*(x-left)/(right-left)
for hardware in ['850','850e']:
    choice=config['hardware'][hardware]
    curves=read(choice['compute_curves']);layers=read(choice['layer_means'])
    assert curves['measured_batches']==layers['batches']==100
    grouped={};sources=[]
    for selected in choice['full_measurements']:
        file=selected if isinstance(selected,str) else selected['file']
        selected_batches=None if isinstance(selected,str) else selected['batches']
        measurement=read(file)
        assert measurement['step_normalization_applied'] is False
        assert all(r['match'] for r in measurement['correctness.json']['ranks'])
        assert measurement['results.json']['dp']==8
        entries=topology_entries(measurement['topology.json'])
        assert entries and all((r['dp'],r['tp'],r['ep'],r['speculative_tokens'])==(8,1,8,5) and r['use_replayssm'] and r['use_kda_recoverssm'] and r['additional_config']['finegrained_tp_config']['qkv_iproj_tensor_parallel_size']==1 for r in entries)
        sources.append({'file':file,'root':measurement['root'],'selected_batches':selected_batches,'case_failure':measurement.get('failure.json')})
        for row in measurement['results.json']['accepted']:
            counters=row['mtp_counters_delta'];batch=row['batch']
            if selected_batches is not None and batch not in selected_batches:continue
            assert row['window_s']>=3 and counters['vllm:num_preemptions_total']==0
            drafts=counters['vllm:spec_decode_num_drafts_total'];assert drafts>0
            grouped.setdefault(batch,[]).append({'window_s':row['window_s'],'drafts':drafts,'cycle_ms':8*batch*row['window_s']/drafts*1000,'input_tokens':row['input'],'output_tokens_requested':row['output'],'source':file})
    assert len(grouped)>=2 and min(grouped)==1,'Need new B1 and at least one larger full-depth anchor'
    anchors={b:8*b*sum(r['window_s'] for r in rows)/sum(r['drafts'] for r in rows)*1000 for b,rows in grouped.items()}
    raw={}
    for point in curves['rows']:
        b=point['batch_per_dp'];v=layers['data'][str(b)]['mean_us']
        extra=33*v['kda_attention_us']+10*v['sfa_attention_us']+30*v['kda_moe_us']+10*v['sfa_moe_us']+3*v['dense_ffn_proxy_us']+33*point['state_commit_us_per_rank_round']
        raw[b]=statistics.median(point['worker_cadence_ms'])+extra/1000
        assert math.isfinite(raw[b]) and raw[b]>0
    xs=sorted(anchors);ratios=[anchors[b]/raw[b] for b in xs]
    for b in range(1,101):
        factor=interpolate(b,xs,ratios);value=raw[b]*factor
        if b in anchors:assert math.isclose(value,anchors[b],rel_tol=1e-10)
        records.append({'hardware':'850E' if hardware=='850e' else '850','batch_per_DP':b,'main_tokens_per_DP':6*b,'full_ITL_estimate_ms_per_cycle_no_step_normalization':value,'raw_layer_model_ms':raw[b],'calibration_factor':factor,'full_depth_measured_anchor':b in anchors,'outside_anchor_range':b<xs[0] or b>xs[-1]})
    holdouts=[]
    for held in xs[1:-1]:
        remaining=[b for b in xs if b!=held]
        predicted=raw[held]*interpolate(held,remaining,[anchors[b]/raw[b] for b in remaining])
        holdouts.append({'held_out_batch':held,'measured_ms':anchors[held],'predicted_from_other_anchors_ms':predicted,'relative_error_percent':100*(predicted/anchors[held]-1)})
    details[hardware]={'anchors_ms':anchors,'anchor_windows':grouped,'calibration_factors':dict(zip(xs,ratios)),'interior_leave_one_anchor_out_checks':holdouts,'sources':sources,'runtime_variant':choice['runtime_variant']}
file=OUT/'glm53-replayssm-only-full-itl.csv'
with file.open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
method={'status':'NEW_FULL_DEPTH_CLIENT_WINDOW_CALIBRATED_ESTIMATE','replayssm':True,'qkv_iproj_tp':1,'step_normalization_applied':False,'curve_points_per_hardware':100,'full_layers':45,'mtp':5,'dp':8,'tp':1,'ep':8,'raw_model':'Measured reduced worker round + 33 KDA-attention + 10 SFA-attention + 30 KDA-MoE + 10 SFA-MoE + 3 dense-FFN proxies + 33 measured per-layer KDA recovery commits. Layer spans include waits and communication. Commit scaling is an approximation because accepted lengths and recovery variants differ between reduced and full workloads; calibration absorbs this at measured anchors.','calibration':'Linear interpolation of measured/raw scale factors between anchors; hold nearest factor outside anchor range. This is not a guarantee of accuracy at unmeasured batches.','anchor_measurement':'Elapsed time over validated full-DP steady windows divided by actual draft rounds, pooled across repeats. Only completed accepted cohorts are used. Separate three-second probes are diagnostic and are not calibration anchors. No fixed accepted-token multiplier. Profiler disabled.','operator_measurement':'Main verification graph only; state commit and five draft steps are represented in total ITL, not the top-ten main-graph panels.','hardware':details,'nonregression_status':config['nonregression_status'],'image_files_read':0,'site_modified':False}
method_file=OUT/'glm53-replayssm-only-full-itl-method.json';method_file.write_text(json.dumps(method,ensure_ascii=False,indent=2),encoding='utf-8')
assert file.stat().st_size<1_000_000 and method_file.stat().st_size<1_000_000
print(json.dumps({'table':str(file),'method':str(method_file),'anchors':{h:d['anchors_ms'] for h,d in details.items()}}))
