"""Extend the current EP8 baseline with explicit GMM-only EP assumptions."""
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
OUT, WORK = ROOT / 'outputs', Path(__file__).resolve().parent
STEM = 'glm53-replayssm-only-'
OPS = ['GroupedMatmulSwigluQuantV2', 'GroupedMatmul']

def read_table(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

baseline_file = OUT / (STEM + 'full-itl.csv')
top_file = OUT / (STEM + 'top10.csv')
baseline = read_table(baseline_file)
top = read_table(top_file)
top_index = {(r['operator'], int(r['batch_per_DP_rank'])): r for r in top}
components = {hw: json.loads((WORK / (hw.lower() + '-gmm.json')).read_text()) for hw in ['850', '850E']}
for d in components.values():
    assert (d['batches'], d['ranks'], d['cycles'], d['GMM_calls_per_type_per_full_cycle']) == (100, 8, 20, 47)
    assert set(map(int, d['data'])) == set(range(1, 101))

rows = []
for r in baseline:
    hw, b = r['hardware'], int(r['batch_per_DP'])
    ep8 = float(r['full_ITL_estimate_ms_per_cycle_no_step_normalization'])
    factor = float(r['calibration_factor'])
    parts = components[hw]['data'][str(b)]
    raw, calibrated = {}, {}
    for op in OPS:
        part = parts[op]
        assert math.isclose(part['reduced_main_ms'] * 1000,
                            float(top_index[op, b][hw + '_us_per_rank_forward']), abs_tol=1e-7)
        raw[op] = part['full_47_calls_per_cycle_ms']
        assert math.isclose(raw[op], 31 * part['KDA_MoE_layer_ms'] + 11 * part['SFA_MoE_layer_ms'] + part['five_draft_calls_ms'], abs_tol=1e-10)
        calibrated[op] = raw[op] * factor
    gmm = sum(calibrated.values())
    remainder = ep8 - gmm
    assert remainder > 0
    row = {'hardware': hw, 'batch_per_DP': b, 'main_tokens_per_DP': 6 * b,
           'EP8_full_ITL_ms_per_cycle': ep8,
           'EP16_full_ITL_ms_per_cycle_GMM_halved': ep8 - .5 * gmm,
           'EP32_full_ITL_ms_per_cycle_GMM_quartered': ep8 - .75 * gmm,
           'EP16_saved_ms_per_cycle': .5 * gmm, 'EP32_saved_ms_per_cycle': .75 * gmm,
           'EP16_ITL_reduction_percent': 50 * gmm / ep8,
           'EP32_ITL_reduction_percent': 75 * gmm / ep8,
           'EP8_full_two_GMM_sum_ms': gmm,
           'unchanged_remainder_ms': remainder,
           'EP8_total_calibration_factor_applied_to_GMM': factor,
           'EP8_full_depth_measured_anchor': r['full_depth_measured_anchor'],
           'EP8_outside_anchor_range': r['outside_anchor_range'],
           'EP16_EP32_status': 'CONDITIONAL_ESTIMATE_NOT_MEASURED'}
    for i, op in enumerate(OPS, 1):
        row[f'GMM{i}_raw_full_47_calls_ms'] = raw[op]
        row[f'GMM{i}_calibrated_full_47_calls_ms'] = calibrated[op]
        row[f'GMM{i}_raw_KDA_MoE_layer_ms'] = parts[op]['KDA_MoE_layer_ms']
        row[f'GMM{i}_raw_SFA_MoE_layer_ms'] = parts[op]['SFA_MoE_layer_ms']
        row[f'GMM{i}_raw_five_draft_calls_ms'] = parts[op]['five_draft_calls_ms']
    assert 0 < row['EP32_full_ITL_ms_per_cycle_GMM_quartered'] < row['EP16_full_ITL_ms_per_cycle_GMM_halved'] < ep8
    rows.append(row)
assert len(rows) == 200
target = OUT / (STEM + 'full-itl-ep8-ep16-ep32.csv')
with target.open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
sources = [baseline_file, top_file, OUT / (STEM + 'full-itl-method.json')] + [WORK / (h + '-gmm.json') for h in ['850', '850e']]
method = {
    'status': 'CONDITIONAL_EP16_EP32_ESTIMATE_FROM_CURRENT_EP8_DATA',
    'EP8_baseline_unchanged': True, 'operator_panels_unchanged': True,
    'hardware': ['850', '850E'], 'ep_levels': [8, 16, 32], 'points_per_curve': 100,
    'same_batch_per_DP': True, 'replayssm': True, 'qkv_iproj_tp': 1,
    'full_main_layers': 45, 'mtp': 5, 'step_normalization_applied': False,
    'scaling_assumption': 'For each hardware and batch per DP, both routed GMM types scale by 8/EP; every other contribution stays fixed.',
    'GMM1': OPS[0], 'GMM2': OPS[1],
    'raw_GMM_per_type': '31 * measured KDA-MoE GMM + 11 * measured SFA-MoE GMM + measured sum of five draft GMM calls.',
    'component_calibration_assumption': 'Apply the CURRENT EP8 total-ITL calibration factor at each batch to each projected GMM component. This is an assumed allocation of the total calibration, not an independent full-depth GMM measurement. Old configuration GMM curves and old B28 anchors are not used.',
    'formula': 'G = current_EP8_calibration_factor * (raw_GMM1 + raw_GMM2); EP16 = EP8 - 0.5*G; EP32 = EP8 - 0.75*G.',
    'limits': [
        'EP16 and EP32 are additive sensitivity estimates, not new multi-node NPU measurements.',
        'Real EP changes can change routing, rank imbalance, communication and computation overlap; these effects are held fixed by assumption.',
        'Summed kernel durations are not generally equal to critical-path wall time. Predicted savings are conditional on the additive assumption.',
        'The current EP8 curve retains its measured anchors and estimation limits, with measured batches listed in the baseline method file.',
        'No memory-capacity or deployment-feasibility claim is made for EP16/EP32.'
    ],
    'sources': [{'name': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
    'selected_points': [r for r in rows if r['batch_per_DP'] in [1, 28, 60, 100]],
    'image_files_read': 0, 'new_NPU_runs': 0, 'online_site_modified': False
}
method_path = OUT / (STEM + 'full-itl-ep8-ep16-ep32-method.json')
method_path.write_text(json.dumps(method, ensure_ascii=False, indent=2), encoding='utf-8')
notes = '''EP16 / EP32 曲线扩展说明

基线：当前 replaySSM only / QKV IProj TP1 的 EP8 曲线。850 和 850E 各有 B1–100。
2×5 个算子图保留当前 EP8 实测数据，底部总 ITL 增加 EP16、EP32，共六条曲线。

沿用旧图的条件假设：同一每 DP batch 下，两类 GMM 在 EP16 缩至 1/2，在 EP32 缩至 1/4，其余耗时不变。
两类 GMM：GroupedMatmulSwigluQuantV2 与 GroupedMatmul。
重新读取本次配置的既有 profiler 文本，在每个 batch 的 8 卡 × 20 周期内分别提取 KDA-MoE、SFA-MoE 及五次 draft 的 GMM 耗时。
每类满层 GMM 原始估算 = 31×KDA-MoE + 11×SFA-MoE + 五次 draft 合计，共 47 次调用。

本次满层校准点没有独立的 GMM profile，因此额外假设：各 batch 的两类 GMM 使用该点当前 EP8 总 ITL 校准系数。
这只是总校准在组成部分间的分配假设，不代表 GMM 已经获得独立满层实测校准。没有套用旧配置的 GMM 曲线或旧 B28 锚点。
令 G 为上述校准后的两类 GMM 合计：EP16 = EP8 - 0.5G；EP32 = EP8 - 0.75G。
总 ITL 保留通信、等待、状态提交和 MTP5；不折算接受步长。

EP16/EP32 是条件估算，不是多机实测；跨机通信、负载均衡、并行重叠等变化未建模。
Kernel 累计耗时不等同关键路径耗时，因此节省量依赖加性假设。
当前 EP8 的实测锚点与局限全部保留，满层实测锚点以 full-itl-method.json 为准。
全程未读取图片，未修改在线网页；每个交付文件小于 1,000,000 字节。
'''
(OUT / (STEM + 'ep-extension-notes.txt')).write_text(notes, encoding='utf-8')
assert target.stat().st_size < 1_000_000 and method_path.stat().st_size < 1_000_000
print(json.dumps({'rows': len(rows), 'selected_points': [
    {k: r[k] for k in ['hardware', 'batch_per_DP', 'EP8_full_ITL_ms_per_cycle', 'EP16_full_ITL_ms_per_cycle_GMM_halved', 'EP32_full_ITL_ms_per_cycle_GMM_quartered']}
    for r in method['selected_points']]}, ensure_ascii=False))
