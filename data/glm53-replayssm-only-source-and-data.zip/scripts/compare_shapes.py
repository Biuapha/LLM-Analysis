import csv,gzip,json
from collections import Counter
from pathlib import Path

HERE=Path(__file__).resolve().parent
OUT=HERE.parents[1]/'outputs'
with gzip.open(HERE/'850-shapes.json.gz','rt',encoding='utf-8') as f:a=json.load(f)
with gzip.open(HERE/'850e-shapes.json.gz','rt',encoding='utf-8') as f:e=json.load(f)
assert a['operators']==e['operators']
assert a['fields']==e['fields'] and a['capacity_masks_zero_indexed']==e['capacity_masks_zero_indexed']
batches=sorted(int(b) for b in a['data'])
assert batches==[1,28,60,100] and set(a['data'])<=set(e['data'])
stats=[];details=[]
for op in a['operators']:
    stats.append(s:={'operator':op,'groups':0,'both_absent_groups':0,'both_metadata_available_groups':0,'active_groups_with_unavailable_metadata':0,'equal_call_count_groups':0,'equal_raw_metadata_groups':0,'equal_after_capacity_mask_groups':0,'equal_known_metadata_after_capacity_mask_groups':0,'equal_ordered_raw_metadata_groups':0,'mismatch_batches_after_capacity_mask':[],'examples':[]})
    for batch in batches:
        x,y=a['data'][str(batch)][op],e['data'][str(batch)][op]
        assert all(len(d[key])==160 for d in [x,y] for key in ['calls','ordered','multiset','capacity_masked_multiset'])
        row={'operator':op,'batch':batch,'groups':160,'calls_850':sum(x['calls']),'calls_850E':sum(y['calls']),'both_absent_groups':sum(m==n==0 for m,n in zip(x['calls'],y['calls']))}
        known=[m and n for m,n in zip(x['metadata_available'],y['metadata_available'])]
        row['both_metadata_available_groups']=sum(known)
        row['active_groups_with_unavailable_metadata']=sum((m or n) and not k for m,n,k in zip(x['calls'],y['calls'],known))
        row['equal_known_metadata_after_capacity_mask_groups']=sum(k and m==n for m,n,k in zip(x['capacity_masked_multiset'],y['capacity_masked_multiset'],known))
        for key in ['both_metadata_available_groups','active_groups_with_unavailable_metadata','equal_known_metadata_after_capacity_mask_groups']:s[key]+=row[key]
        for source,label in [('calls','equal_call_count_groups'),('multiset','equal_raw_metadata_groups'),('capacity_masked_multiset','equal_after_capacity_mask_groups'),('ordered','equal_ordered_raw_metadata_groups')]:
            row[label]=sum(m==n for m,n in zip(x[source],y[source]));s[label]+=row[label]
        s['groups']+=160;s['both_absent_groups']+=row['both_absent_groups']
        if row['equal_after_capacity_mask_groups']<160:
            s['mismatch_batches_after_capacity_mask'].append(batch)
            if len(s['examples'])<3:
                cx,cy=Counter(x['signatures']),Counter(y['signatures'])
                s['examples'].append({'batch':batch,'850_unmatched':[{'metadata':dict(zip(a['fields'],a['vocabulary'][key])),'count':count} for key,count in (cx-cy).items()][:3],'850E_unmatched':[{'metadata':dict(zip(e['fields'],e['vocabulary'][key])),'count':count} for key,count in (cy-cx).items()][:3]})
        details.append(row)
    assert s['groups']==160*len(batches)
report={'scope':'same batch, rank, and 20-cycle main-forward windows as the chart','batches':len(batches),'batch_values':batches,'status':'FOUR_REPRESENTATIVE_COMMON_BATCHES','ranks':8,'cycles':20,'metadata_fields':a['fields'],'capacity_masks_zero_indexed':a['capacity_masks_zero_indexed'],'capacity_note':'K/V pool leading dimensions and separately identified RecurrentKda state-cache leading dimensions are masked; all other dimensions, dtype and format remain exact.','operators':stats,'image_files_read':0,'limitation':'Equality of missing/NA metadata is not evidence of equal shapes. Profiler metadata comparison does not establish equal input values, tensor strides, internal tiling, or dynamic expert-token distributions.'}
path=OUT/'glm53-replayssm-only-partial-shape-audit.json'
path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'glm53-replayssm-only-partial-shape-audit-by-batch.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(details[0]));writer.writeheader();writer.writerows(details)
assert path.stat().st_size<1_000_000
print(json.dumps([{k:v for k,v in s.items() if k!='examples'} for s in stats],ensure_ascii=False,indent=2))
