"""Build the new figure only from complete, independently measured QKV-TP1 data."""
from pathlib import Path
import csv
import gzip
import hashlib
import json
import subprocess
import sys
import zipfile

P=Path(__file__).resolve().parent
OUT=P.parents[1]/'outputs'
STEM='glm53-replayssm-only-'
provenance={}
for hw in ['850','850e']:
    sources=[P/(hw+suffix) for suffix in ['-compute-curves.json.gz','-layer-means.json.gz','-gmm.json','-shapes.json.gz','-provenance.json','-full-measurements.json.gz','-full-provenance.json']]
    assert all(f.exists() and 0<f.stat().st_size<1000000 for f in sources)
    prov=json.loads((P/f'{hw}-provenance.json').read_text())
    full=json.loads((P/f'{hw}-full-provenance.json').read_text())
    assert prov['root']==json.loads((P/f'{hw}-config.json').read_text())['root']
    assert full['root']==prov['root']+'/full-replayonly'
    assert len(prov['topology'])==8
    assert all(x['use_replayssm'] and x['finegrained_tp_config']['qkv_iproj_tensor_parallel_size']==1 for x in prov['topology'])
    assert all(x['match'] for x in full['correctness']['ranks'])
    if prov.get('resumption'):
        assert prov['resumption']['runtime_and_topology_reverified']
        assert not prov['resumption']['prior_ownership_events'], 'Review ownership events before interruption'
    for scope,events in [('reduced',prov['ownership_events']),('full',full['ownership_events'])]:
        for event in events:
            assert not any(x['classification']=='live_foreign' for x in event['observed']), (hw,scope,event)
            if event.get('sweep_progress') is not None:
                assert not any(x['classification'] in ['already_exited','zombie'] for x in event['observed']), ('Review unattributed process during measured sweep',hw,event)
    with gzip.open(P/f'{hw}-compute-curves.json.gz','rt') as f:curves=json.load(f)
    assert curves['measured_batches']==100 and curves['qkv_iproj_tp']==1 and curves['replayssm']
    provenance[hw]={'host':prov['host'],'root':prov['root'],'runtime_hashes':prov['runtime_hashes'],'ownership_events':prov['ownership_events'],'full_ownership_events':full['ownership_events'],'sources':[{'file':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sources]}
    if prov.get('resumption'):provenance[hw]['resumption']=prov['resumption']
    if prov.get('cross_host_validation'):
        review=json.loads((P/'cross-host-review.json').read_text())
        assert review['accepted'] and review['checked_batches']==[1,28,60,69,100]
        provenance[hw]['cross_host_validation']=prov['cross_host_validation']
        provenance[hw]['cross_host_layer_validation']=prov['cross_host_layer_validation']
        provenance[hw]['cross_host_review']=review
        provenance[hw]['batch_hosts']=prov['batch_hosts']
    provenance[hw]['full_measurement_state']=full['state']['stage']
    if full['state']['stage']!='complete':
        with gzip.open(P/f'{hw}-full-measurements.json.gz','rt') as f:full_data=json.load(f)
        provenance[hw]['full_measurement_failure']=full_data.get('failure.json')
        provenance[hw]['full_measurement_limitation']='Full-depth B100 hit preemption while building the target-batch cohort under the current 128K-input/8K-output configuration. Only accepted cohorts are used as calibration anchors; points above the largest valid anchor are extrapolated.'

for args in [['build_curve_tables.py'],['build_full_curves.py','full-curve-inputs.json'],['build_ep_curves.py'],['compare_shapes.py'],['plot_ep_combined.py']]:
    subprocess.run([sys.executable,'-X','utf8',str(P/args[0]),*[str(P/a) for a in args[1:]]],check=True)

method=json.loads((OUT/(STEM+'full-itl-method.json')).read_text())
validation=json.loads((OUT/(STEM+'top10-and-full-itl-ep8-ep16-ep32-validation.json')).read_text())
assert method['qkv_iproj_tp']==1 and not method['step_normalization_applied']
assert validation['all_lines_match_CSV'] and validation['geometry_checked']
anchors={h:d['anchors_ms'] for h,d in method['hardware'].items()}
report={'configuration':{'replayssm':True,'qkv_iproj_tp':1,'dp':8,'tp':1,'ep8_measured':True,'ep16_ep32_measured':False,'mtp':5},'completed':True,'operator_points_per_hardware':100,'full_depth_anchors_ms':anchors,'full_ITL':'Layer-span estimate calibrated to current full-depth unprofiled client windows; outside the anchor range is extrapolation.','EP16_EP32':'GMM-only conditional estimates: both GMM contributions scale by 8/EP; all other costs fixed.','step_normalization_applied':False,'image_files_read':0,'site_modified':False,'provenance':provenance,'excluded_attempts':['850194/850E113 run interrupted by foreign NPU work; no samples from that attempt used.','850198 startup before ownership checks was preserved separately; it produced no measured batches.']}
report['excluded_attempts'].append('850E114 was interrupted twice and its container was subsequently removed; no samples from that host are used. 850E110 completed batches are retained only after overlap validation on 850E101; per-batch hosts are recorded in provenance.')
report['excluded_attempts'].append('The first 850198 full-depth calibration was interrupted by a container stop and preserved in full-interruption-182501. Final 850 anchors use the subsequent complete four-batch run only.')
report_file=OUT/(STEM+'measurement-report.json')
report_file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

notes='ReplaySSM only（KDA QKV TP 关闭）\n\n上方 2×5：850 与 850E 各 B1–100 的 Top10 非通信算子实测。\n下方：EP8 满层 ITL 校准估算，以及 EP16/EP32 条件估算。\n配置：DP8 / TP1 / QKV IProj TP1 / MTP5；输入128K。算子采集输出1K，满层校准输出8K。\n满层 ITL 按实际 draft rounds 计时，不折算接受步长。\n满层实测校准点（ms/轮）：'+json.dumps(anchors,ensure_ascii=False)+'\n其他 batch 使用分层耗时模型；锚点范围外为外推。\nEP16/32 仅缩放两类 GMM，未实测多机通信、负载均衡与重叠变化。\n未读取图片，未更新在线网页；每个交付文件小于1,000,000字节。\n'
(OUT/(STEM+'notes.txt')).write_text(notes,encoding='utf-8')
if 'cross_host_review' in provenance['850e']:
    with (OUT/(STEM+'notes.txt')).open('a',encoding='utf-8') as f:
        f.write('\n850E 使用 110 已完成批次与 101 补测批次，逐 batch 来源见 measurement-report。五个重叠 batch 的 Top10 算子最大差异 1.42%；包含通信/等待的原始分层模型最大差异 7.22%，不是误差上限或置信区间。底部 ITL 用 101 新满层实测点校准。\n')

archive=OUT/(STEM+'source-and-data.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for pattern in ['*-compute-curves.json.gz','*-layer-means.json.gz','*-gmm.json','*-shapes.json.gz','*-provenance.json','*-full-measurements.json.gz']:
        for f in sorted(P.glob(pattern)):z.write(f,'data/'+f.name)
    for name in ['build_curve_tables.py','build_full_curves.py','build_ep_curves.py','compare_shapes.py','plot_ep_combined.py','finalize.py','full-curve-inputs.json','cross-host-review.json']:
        z.write(P/name,'scripts/'+name)
    for f in sorted(OUT.glob(STEM+'*.csv')):z.write(f,'tables/'+f.name)
files=[f for f in OUT.glob(STEM+'*') if f.is_file()]
assert all(0<f.stat().st_size<1000000 for f in files),[(f.name,f.stat().st_size) for f in files]
(P/'state.json').write_text(json.dumps({'complete':True,'configuration':report['configuration'],'files':[{'name':f.name,'bytes':f.stat().st_size} for f in files]},indent=2))
print(json.dumps({'complete':True,'anchors_ms':anchors,'files':[{'name':f.name,'bytes':f.stat().st_size} for f in files]},ensure_ascii=False))
